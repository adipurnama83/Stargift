<?php 

 $uuid = "465d100b-5bc4-4d8e-ac42-1d28b6c6b8c3";

 $carrier = "Vietnamobile";

 //Google-Advertiser-Id
 $idd = "18e4e4c2-8076-4a47-8fce-041974c4c6e6";

 //Device-Name
 $device = "Redmi 4A";

 //Android-Id
 $android = "d1f5e979507aec3a";
 
 //Authorization
 $auth = "Bearer 21e5f820-a242-4541-bbe4-77154606f541";
 
?>

